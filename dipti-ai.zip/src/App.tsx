import React, { useEffect, useRef, useState } from "react";
import { 
  Mic, 
  MicOff, 
  Bell, 
  Phone, 
  Settings, 
  Database, 
  Activity, 
  Trash2, 
  Plus, 
  Cpu, 
  FolderHeart, 
  Clock, 
  Battery, 
  Wifi, 
  MessageSquare, 
  Sparkles, 
  Info,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Music,
  Send
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useDiptiStore } from "./store/diptiStore";
import { DiptiLiveService } from "./services/DiptiLiveService";
import { AndroidPermissionState } from "./types";

export default function App() {
  const {
    diptiState,
    isConnected,
    inputVolume,
    outputVolume,
    permissionState,
    intentLogs,
    pastConversations,
    references,
    currentInputText,
    currentOutputText,
    selectedLanguage,
    togglePermission,
    setLanguage,
    addIntentLog,
    fetchConversations,
    fetchReferences,
    addReferenceCard,
    deleteReferenceCard,
    clearConversationHistory,

    // Simulated Android Screens & States
    activeAndroidScreen,
    whatsappChats,
    activeWhatsAppChatId,
    musicPlaying,
    currentTrackIndex,
    musicProgressStep,
    tracks,
    setAndroidScreen,
    setActiveWhatsAppChat,
    sendWhatsAppMessage,
    playMusic,
    pauseMusic,
    nextTrack,
    prevTrack,
  } = useDiptiStore();

  const serviceRef = useRef<DiptiLiveService | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const waChatEndRef = useRef<HTMLDivElement | null>(null);

  // Local state for adding memory reference card manual input
  const [showAddRefModal, setShowAddRefModal] = useState(false);
  const [refTitle, setRefTitle] = useState("");
  const [refContent, setRefContent] = useState("");
  const [refCategory, setRefCategory] = useState<"general" | "note" | "reminder" | "link" | "contact">("general");

  // Local state for simulated WhatsApp input
  const [waText, setWaText] = useState("");

  // Local UI view configurations
  const [currentTab, setCurrentTab] = useState<"chat" | "database" | "intents">("chat");
  const [time, setTime] = useState("");

  // Auto scroll transcript layout
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [pastConversations, currentInputText, currentOutputText]);

  // Auto scroll WhatsApp message bubbles when active chat or messaging changes
  useEffect(() => {
    if (waChatEndRef.current) {
      waChatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [whatsappChats, activeWhatsAppChatId, activeAndroidScreen]);

  // Synchronise system clock time in the status bar
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Hydrate database tables on startup
  useEffect(() => {
    fetchConversations();
    fetchReferences();
  }, []);

  const handleToggleConnection = async () => {
    if (isConnected) {
      if (serviceRef.current) {
        serviceRef.current.disconnect();
        serviceRef.current = null;
      }
    } else {
      try {
        serviceRef.current = new DiptiLiveService();
        await serviceRef.current.connect();
      } catch (err: any) {
        console.error("Connection attempt aborted:", err);
        alert(`Failed to start Dipti Assistant: ${err.message || String(err)}\n\nPlease ensure your GEMINI_API_KEY is configured in the Secrets panel.`);
      }
    }
  };

  const handleManualAddRef = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refTitle || !refContent) return;
    await addReferenceCard(refTitle, refContent, refCategory);
    setRefTitle("");
    setRefContent("");
    setRefCategory("general");
    setShowAddRefModal(false);
  };

  const handleResetDb = async () => {
    if (confirm("Are you sure you want to clear Dipti's conversational memory and references?")) {
      await clearConversationHistory();
    }
  };

  // WhatsApp reply simulator
  const handleSendWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!waText.trim()) return;

    const activeChat = whatsappChats.find(c => c.id === activeWhatsAppChatId);
    if (!activeChat) return;

    const userMessageText = waText;
    setWaText("");

    // Append user message on local chat thread
    sendWhatsAppMessage(activeWhatsAppChatId, userMessageText, "user");

    // Add immediate system log intent
    useDiptiStore.getState().addIntentLog({
      id: `whatsapp-${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: "com.whatsapp.intent.action.SEND_MSG",
      packageName: "com.whatsapp",
      extras: { recipient: activeChat.contactName, msg: userMessageText },
      status: "executed"
    });

    // Simulate conversational companion / contact replies after 1.5s
    setTimeout(() => {
      let reply = "ठीक है भैया, मैं देख लेता हूँ! (Got it bro, I will check!)";
      if (activeWhatsAppChatId === "chat-preeti") {
        reply = "ভালেই লাগে! আজি ৰাতি কথা পাতিম তেন্তে। (Feels great! Let's talk tonight then.)";
      } else if (activeWhatsAppChatId === "chat-rahul") {
        reply = "Excellent work. I will push the parameters onto our local branch.";
      }
      sendWhatsAppMessage(activeWhatsAppChatId, reply, "contact");
    }, 1500);
  };

  // Helper colors mapping to Dipti's mood state
  const getOrbColor = () => {
    switch (diptiState) {
      case "connecting":
        return "from-yellow-400 to-amber-600";
      case "listening":
        return "from-cyan-400 to-blue-600";
      case "thinking":
        return "from-indigo-500 via-purple-600 to-pink-600";
      case "speaking":
        return "from-emerald-400 via-teal-500 to-green-600 animate-pulse";
      case "disconnected":
      default:
        return "from-slate-700 to-slate-900";
    }
  };

  // Human descriptive text for Dipti's operational states
  const getStatusText = () => {
    switch (diptiState) {
      case "connecting":
        return "দীপ্তি কানেক্ট হৈ আছে... (Dipti is connecting...)";
      case "listening":
        return "दीप्ती सुन रही है... बोलिए (Dipti is listening... Speak)";
      case "thinking":
        return "दीप्ती सोच रही है... (Dipti is processing...)";
      case "speaking":
        return "दीप्ती बोल रही है... (Dipti is speaking...)";
      case "disconnected":
      default:
        return "Dipti is Offline. Click the Orb to Start Conversation";
    }
  };

  const activeChat = whatsappChats.find(c => c.id === activeWhatsAppChatId) || whatsappChats[0];
  const activeTrack = tracks[currentTrackIndex];

  return (
    <div id="dipti-container" className="relative min-h-screen bg-[#070913] text-[#f8fafc] overflow-x-hidden font-sans flex flex-col items-center justify-center p-4 selection:bg-[#06b6d4] selection:text-black">
      
      {/* Immersive moving space background blobs with elegant filters */}
      <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-[#1e1e4f] opacity-20 blur-[120px] pointer-events-none animate-pulse"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[45vw] h-[45vw] rounded-full bg-[#2a1340] opacity-20 blur-[130px] pointer-events-none"></div>
      <div className="absolute top-[40%] right-[10%] w-[35vw] h-[35vw] rounded-full bg-[#0d4f54] opacity-10 blur-[100px] pointer-events-none"></div>

      {/* Grid of full content */}
      <div className="relative w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch my-auto">
        
        {/* LEFT PANEL: Advanced Android Permission & Simulator Inputs */}
        <section className="lg:col-span-4 flex flex-col gap-5 bg-slate-950/40 backdrop-blur-md rounded-2xl border border-slate-800/60 p-5 self-stretch">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Cpu className="text-cyan-400 w-5 h-5" />
            <h2 className="font-semibold text-lg text-slate-200">Android Host Simulator</h2>
          </div>

          {/* Simulated App Metadata banner */}
          <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-cyan-950 flex items-center justify-center border border-cyan-500/30">
                <span className="text-cyan-400 font-mono font-bold text-sm">D</span>
              </div>
              <div>
                <h3 className="font-semibold text-xs text-slate-300">Android SDK 35 Target</h3>
                <p className="text-[10px] text-slate-500">PWA Active | Echo Suppressed</p>
              </div>
            </div>
            <div className="flex gap-1 items-center">
              <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400 animate-ping' : 'bg-rose-500'}`} />
              <span className="font-mono text-[10px] text-slate-400">{isConnected ? "ONLINE" : "OFFLINE"}</span>
            </div>
          </div>

          {/* Active app shortcut triggers inside Left Panel */}
          <div className="bg-slate-900/30 border border-slate-800/60 p-3 rounded-xl flex flex-col gap-2.5">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1">Device Launcher Apps</h4>
            <div className="grid grid-cols-3 gap-1.5">
              <button 
                onClick={() => setAndroidScreen("dipti")}
                className={`py-2 px-1 rounded-lg border text-xs font-semibold flex flex-col items-center gap-1.5 transition ${activeAndroidScreen === "dipti" ? "bg-cyan-950/40 border-cyan-500 text-cyan-400" : "bg-slate-950/50 border-slate-850 hover:bg-slate-900 text-slate-300"}`}
              >
                <Sparkles className="w-4 h-4" />
                <span>Dipti AI</span>
              </button>
              <button 
                onClick={() => setAndroidScreen("whatsapp")}
                className={`py-2 px-1 rounded-lg border text-xs font-semibold flex flex-col items-center gap-1.5 transition ${activeAndroidScreen === "whatsapp" ? "bg-emerald-950/40 border-emerald-500 text-emerald-400" : "bg-slate-950/50 border-slate-850 hover:bg-slate-900 text-slate-300"}`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>
              <button 
                onClick={() => setAndroidScreen("music")}
                className={`py-2 px-1 rounded-lg border text-xs font-semibold flex flex-col items-center gap-1.5 transition ${activeAndroidScreen === "music" ? "bg-purple-950/40 border-purple-500 text-purple-400" : "bg-slate-950/50 border-slate-850 hover:bg-slate-900 text-slate-300"}`}
              >
                <Music className="w-4 h-4" />
                <span>Music app</span>
              </button>
            </div>
          </div>

          {/* Quick permissions toggles */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold text-slate-400 tracking-wider uppercase">Device Permission Shields</h4>
              <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">Dynamic</span>
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              {(Object.keys(permissionState) as Array<keyof AndroidPermissionState>).map((key) => (
                <div key={key} className="flex items-center justify-between bg-slate-900/40 border border-slate-800/40 px-3 py-1.5 rounded-lg hover:border-slate-700/60 transition">
                  <div className="flex items-center gap-2">
                    {key === "microphone" && <Mic className="w-3.5 h-3.5 text-cyan-400" />}
                    {key === "phone_calls" && <Phone className="w-3.5 h-3.5 text-emerald-400" />}
                    {key === "sms" && <MessageSquare className="w-3.5 h-3.5 text-purple-400" />}
                    {key === "notifications" && <Bell className="w-3.5 h-3.5 text-amber-400" />}
                    {key === "alarms" && <Clock className="w-3.5 h-3.5 text-rose-400" />}
                    {key === "contacts" && <FolderHeart className="w-3.5 h-3.5 text-pink-400" />}
                    <span className="capitalize text-[11px] text-slate-300 font-medium">
                      {key.replace("_", " ")}
                    </span>
                  </div>
                  <button
                    onClick={() => togglePermission(key)}
                    className={`relative inline-flex h-4.5 w-8.5 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${permissionState[key] ? "bg-cyan-500" : "bg-slate-800"}`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${permissionState[key] ? "translate-x-4" : "translate-x-0"}`}
                    />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Informational Hint Card */}
          <div className="mt-auto bg-cyan-950/20 border border-cyan-800/30 rounded-lg p-3 text-xs leading-relaxed text-slate-300 flex gap-2">
            <Info className="text-cyan-400 shrink-0 w-4 h-4 mt-0.5" />
            <p>
              <strong>Offline Synthesizer:</strong> Tell Dipti: <em>"Play bihu melody"</em> to hear real, synthesized vocal accompaniment or <em>"Send WhatsApp to Preeti saying I love Assamese music"</em>.
            </p>
          </div>
        </section>

        {/* MIDDLE PANEL: The Immersive Android Device & Display Screen */}
        <section className="lg:col-span-4 flex flex-col bg-gradient-to-b from-slate-900 via-slate-950 to-black rounded-3xl border border-slate-800/80 p-5 shadow-2xl relative self-stretch overflow-hidden aspect-[9/16] lg:h-auto min-h-[580px]">
          
          {/* Simulated android device top status bar */}
          <div className="flex items-center justify-between text-xs text-slate-300 mb-4 font-mono px-1 select-none border-b border-slate-800/30 pb-2">
            <span className="font-semibold text-[10px]">DiptiOS 1.0</span>
            <div className="flex items-center gap-2">
              <Wifi className="w-3 h-3 text-slate-400" />
              <Battery className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px]">{time || "14:52"}</span>
            </div>
          </div>

          {/* DYNAMIC SCREEN LAYOUT */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <AnimatePresence mode="wait">
              
              {/* SCREEN 1: VOCAL ASSISTANT (DIPTI CORE ORB) */}
              {activeAndroidScreen === "dipti" && (
                <motion.div 
                  key="screen-dipti"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="flex-1 flex flex-col items-center justify-between py-2"
                >
                  <div className="flex flex-col items-center justify-center text-center">
                    <div className="flex items-center gap-1 bg-cyan-950/30 text-cyan-400 text-[9px] font-semibold border border-cyan-800/20 px-2 py-0.5 rounded-full mb-1">
                      <Sparkles className="w-2.5 h-2.5 text-cyan-400" />
                      NATIVE ASSISTANT
                    </div>
                    <h1 className="text-xl font-bold bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
                      Dipti AI
                    </h1>
                    <p className="text-[10px] text-slate-400">
                      Hindi & Assamese Female Vocal Mate
                    </p>
                  </div>

                  {/* Animated Voice Orb Centerpiece */}
                  <div className="relative my-auto">
                    <div 
                      style={{ transform: `scale(${1 + (isConnected ? (diptiState === "speaking" ? outputVolume * 1.8 : inputVolume * 1.5) : 0)})` }}
                      className={`absolute inset-[-30px] rounded-full bg-gradient-to-r ${getOrbColor()} opacity-25 blur-xl transition-all duration-75`}
                    />
                    <div 
                      style={{ transform: `scale(${1 + (isConnected ? (diptiState === "speaking" ? outputVolume * 1.2 : inputVolume * 0.9) : 0)})` }}
                      className={`absolute inset-[-15px] rounded-full bg-gradient-to-r ${getOrbColor()} opacity-30 blur-lg transition-all duration-100`}
                    />

                    <button 
                      id="toggle-dipti-btn-internal"
                      onClick={handleToggleConnection}
                      className="relative w-32 h-32 rounded-full flex items-center justify-center overflow-hidden border border-slate-700/60 cursor-pointer shadow-lg active:scale-95 transition-transform"
                    >
                      <div className={`absolute inset-0 bg-gradient-to-r ${getOrbColor()} opacity-90 transition-all duration-300`} />
                      
                      {diptiState === "thinking" && (
                        <motion.div 
                          animate={{ rotate: 360, borderRadius: ["40% 60% 70% 30% / 40% 50% 60% 50%", "70% 30% 52% 48% / 60% 40% 60% 40%"] }}
                          transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                          className="absolute inset-1.5 bg-gradient-to-tr from-pink-500 via-purple-700 to-indigo-800"
                        />
                      )}

                      {diptiState === "listening" && (
                        <motion.div 
                          animate={{ scale: [1, 1.15, 1] }}
                          transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
                          className="absolute inset-0 bg-cyan-700/40 rounded-full"
                        />
                      )}

                      <div className="relative z-10 flex flex-col items-center justify-center text-white text-center p-1 select-none">
                        {isConnected ? (
                          diptiState === "speaking" ? (
                            <Activity className="w-7 h-7 text-white animate-pulse" />
                          ) : diptiState === "thinking" ? (
                            <div className="flex gap-1">
                              <span className="w-2 h-2 rounded-full bg-white animate-bounce [animation-delay:-0.3s]" />
                              <span className="w-2 h-2 rounded-full bg-white animate-bounce [animation-delay:-0.15s]" />
                              <span className="w-2 h-2 rounded-full bg-white animate-bounce" />
                            </div>
                          ) : (
                            <Mic className="w-8 h-8 text-white" />
                          )
                        ) : (
                          <MicOff className="w-8 h-8 text-slate-400" />
                        )}
                        <span className="text-[9px] uppercase font-bold tracking-widest mt-1 font-mono">
                          {isConnected ? diptiState : "CONNECT"}
                        </span>
                      </div>
                    </button>
                  </div>

                  <p className="text-[11px] text-center font-medium text-slate-300 max-w-[200px] px-2 bg-slate-950/40 py-2.5 rounded-xl border border-slate-800/40">
                    {getStatusText()}
                  </p>
                </motion.div>
              )}

              {/* SCREEN 2: MOCK WHATSAPP MESSENGER */}
              {activeAndroidScreen === "whatsapp" && (
                <motion.div 
                  key="screen-whatsapp"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="flex-1 flex flex-col bg-slate-900/20 rounded-xl overflow-hidden border border-slate-800/50"
                >
                  {/* WhatsApp Top bar */}
                  <div className="bg-emerald-800/95 p-3 flex items-center justify-between text-white shadow-sm shrink-0">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full ${activeChat.avatarColor} flex items-center justify-center font-bold text-xs uppercase shadow-sm border border-white/20`}>
                        {activeChat.contactName.substring(0, 2)}
                      </div>
                      <div>
                        <h4 className="font-bold text-xs leading-none text-slate-100">{activeChat.contactName}</h4>
                        <span className="text-[9px] text-emerald-250 animate-pulse">Online & Active</span>
                      </div>
                    </div>
                    <MessageSquare className="w-4 h-4 text-emerald-200" />
                  </div>

                  {/* Chat Threads Switcher bar */}
                  <div className="bg-[#111b21] px-2 py-1.5 border-b border-slate-800 shadow-inner flex gap-1.5 overflow-x-auto shrink-0 scrollbar-none">
                    {whatsappChats.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => setActiveWhatsAppChat(c.id)}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition flex items-center gap-1 shrink-0 ${activeWhatsAppChatId === c.id ? "bg-emerald-700 text-white" : "bg-slate-900 border border-slate-800/60 text-slate-400 hover:text-white"}`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${c.avatarColor}`} />
                        {c.contactName.split(" ")[0]}
                      </button>
                    ))}
                  </div>

                  {/* Message Balloon List */}
                  <div className="flex-1 bg-[#121c21] p-3 overflow-y-auto space-y-2 flex flex-col justify-start">
                    {activeChat.messages.map((m) => {
                      const isMe = m.sender === "user";
                      const isDipti = m.sender === "dipti";
                      return (
                        <div 
                          key={m.id}
                          className={`max-w-[85%] flex flex-col gap-0.5 ${isMe || isDipti ? "ml-auto items-end" : "mr-auto items-start"}`}
                        >
                          <div className={`p-2.5 rounded-xl text-xs break-words shadow-sm ${
                            isMe 
                              ? "bg-emerald-600/90 text-white rounded-tr-none" 
                              : isDipti 
                                ? "bg-cyan-600/90 text-white rounded-tr-none" 
                                : "bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700/40"
                          }`}>
                            <p>{m.text}</p>
                          </div>
                          <span className="text-[8px] text-slate-500 font-mono px-1">
                            {isDipti ? "Dipti OS" : m.sender === "user" ? "You" : activeChat.contactName} • {m.timestamp}
                          </span>
                        </div>
                      );
                    })}
                    <div ref={waChatEndRef} />
                  </div>

                  {/* Input entry */}
                  <form onSubmit={handleSendWhatsApp} className="p-2 bg-[#1f2c34] border-t border-slate-800 flex gap-1.5 shrink-0">
                    <input 
                      type="text"
                      value={waText}
                      onChange={(e) => setWaText(e.target.value)}
                      placeholder={`Message ${activeChat.contactName.split(" ")[0]}...`}
                      className="flex-1 bg-[#2a3942] border border-transparent focus:border-slate-700 focus:outline-none text-xs rounded-lg py-1.5 px-3 text-white"
                    />
                    <button 
                      type="submit"
                      className="bg-emerald-600 hover:bg-emerald-500 text-white p-2.5 rounded-full flex items-center justify-center transition cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </motion.div>
              )}

              {/* SCREEN 3: HIGH-TECH MEDIA MUSIC PLAYER */}
              {activeAndroidScreen === "music" && (
                <motion.div 
                  key="screen-music"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex-1 flex flex-col bg-slate-950/40 rounded-xl overflow-hidden border border-slate-850 p-4 justify-between"
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="flex gap-1 items-center bg-purple-950/30 text-purple-400 text-[9px] font-semibold border border-purple-800/10 px-2 py-0.5 rounded-full mb-2">
                      <Music className="w-2.5 h-2.5 text-purple-400" />
                      ANDROID SYSTEM PLAYER
                    </div>
                    <h3 className="text-sm font-bold text-slate-100 font-mono">{activeTrack.title}</h3>
                    <p className="text-[10px] text-slate-400">{activeTrack.artist}</p>
                    <span className="text-[9px] text-[#06b6d4] uppercase tracking-wider font-semibold mt-1 bg-cyan-950/20 px-1.5 py-0.5 rounded border border-cyan-900/30">
                      {activeTrack.genre}
                    </span>
                  </div>

                  {/* Rotating CD Vinyl Record and visualizer bar */}
                  <div className="flex flex-col items-center justify-center my-4 relative">
                    <div className={`w-28 h-28 rounded-full bg-slate-900 border-4 border-slate-850 flex items-center justify-center relative shadow-xl overflow-hidden ${musicPlaying ? "animate-[spin_6s_linear_infinite]" : ""}`}>
                      <div className="absolute inset-3 rounded-full border border-slate-800 flex items-center justify-center">
                        <div className="absolute inset-5 bg-purple-600/10 rounded-full border border-purple-900/30 flex items-center justify-center">
                          {/* Inner gold center block */}
                          <div className="w-6 h-6 rounded-full bg-[#06b6d4]" />
                        </div>
                      </div>
                    </div>

                    {/* Cyber visualizer columns */}
                    <div className="flex gap-1 items-end h-6 mt-4 opacity-80">
                      {[1, 2, 3, 4, 5, 4, 3, 2, 1].map((bar, i) => (
                        <motion.div
                          key={i}
                          animate={musicPlaying ? { height: [4, bar * 4, 4] } : { height: 4 }}
                          transition={{ repeat: Infinity, duration: 0.6 + (i * 0.08), ease: "easeInOut" }}
                          className="w-1 bg-[#06b6d4] rounded"
                        />
                      ))}
                    </div>
                  </div>

                  {/* Progressive scrolling tracker indicator */}
                  <div className="space-y-1 w-full px-1">
                    <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                      <span>STEP {musicProgressStep + 1} / 16 BEATS</span>
                      <span>{musicPlaying ? "PLAYBACK LIVE" : "PAUSED"}</span>
                    </div>
                    <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-850">
                      <div 
                        className="bg-[#06b6d4] h-full duration-200 transition-all rounded-full"
                        style={{ width: `${((musicProgressStep + 1) / 16) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Mechanical Tracker Buttons */}
                  <div className="flex items-center justify-center gap-5 my-2.5">
                    <button 
                      onClick={() => {
                        prevTrack();
                        addIntentLog({
                          id: `intent-${Date.now()}`,
                          timestamp: new Date().toISOString(),
                          action: "android.intent.action.MEDIA_BUTTON",
                          extras: { command: "prev" },
                          status: "executed"
                        });
                      }}
                      className="p-2 hover:bg-slate-900/60 rounded-full transition text-slate-400 hover:text-white cursor-pointer"
                    >
                      <SkipBack className="w-4 h-4" />
                    </button>

                    <button 
                      onClick={() => {
                        const playState = musicPlaying;
                        if (playState) {
                          pauseMusic();
                        } else {
                          playMusic();
                        }
                        addIntentLog({
                          id: `intent-${Date.now()}`,
                          timestamp: new Date().toISOString(),
                          action: "android.intent.action.MEDIA_BUTTON",
                          extras: { command: playState ? "pause" : "play" },
                          status: "executed"
                        });
                      }}
                      className="p-3 bg-[#06b6d4] hover:bg-[#22d3ee] rounded-full text-black transition transform active:scale-95 shadow-md flex items-center justify-center cursor-pointer"
                    >
                      {musicPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </button>

                    <button 
                      onClick={() => {
                        nextTrack();
                        addIntentLog({
                          id: `intent-${Date.now()}`,
                          timestamp: new Date().toISOString(),
                          action: "android.intent.action.MEDIA_BUTTON",
                          extras: { command: "next" },
                          status: "executed"
                        });
                      }}
                      className="p-2 hover:bg-slate-900/60 rounded-full transition text-slate-400 hover:text-white cursor-pointer"
                    >
                      <SkipForward className="w-4 h-4" />
                    </button>
                  </div>

                  {/* List of track rows inside screen */}
                  <div className="space-y-1 shrink-0">
                    {tracks.map((t, idx) => (
                      <button
                        key={t.id}
                        onClick={() => playMusic(t.id)}
                        className={`w-full py-1.5 px-2.5 rounded text-[10px] flex items-center justify-between transition ${currentTrackIndex === idx ? "bg-[#06b6d4]/10 border border-[#06b6d4]/30 text-[#06b6d4]" : "bg-slate-900/40 border border-transparent text-slate-400 hover:text-white hover:bg-slate-900"}`}
                      >
                        <div className="flex items-center gap-1.5">
                          <Music className="w-3 h-3 text-slate-500" />
                          <span className="font-semibold truncate max-w-[140px]">{t.title}</span>
                        </div>
                        <span className="font-mono text-[9px] text-slate-500">{idx === 0 ? "Bihu" : idx === 1 ? "Lofi" : "Chime"}</span>
                      </button>
                    ))}
                  </div>

                </motion.div>
              )}

            </AnimatePresence>
          </div>

          {/* SIMULATED SOFTWARE NAVIGATION BAR (HOME, DRAWERS, SHORTCUTS) */}
          <div className="mt-4 pt-3 border-t border-slate-900/60 flex items-center justify-around text-slate-400 shrink-0">
            <button 
              onClick={() => {
                // If on subscreen, go back to main Dipti OS screen
                if (activeAndroidScreen !== "dipti") {
                  setAndroidScreen("dipti");
                } else {
                  alert("Already on default voice companion dashboard.");
                }
              }}
              title="Simulator Back button"
              className="p-2 hover:bg-slate-900 hover:text-white rounded-lg transition"
            >
              <svg className="w-4 h-4 fill-current rotate-180" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </button>
            <button 
              onClick={() => setAndroidScreen("dipti")}
              title="Simulator Home button"
              className={`p-2 rounded-lg transition ${activeAndroidScreen === "dipti" ? "text-[#06b6d4] bg-cyan-950/20" : "hover:bg-slate-900 hover:text-white"}`}
            >
              <span className="w-3.5 h-3.5 block rounded-full border-2 border-current" />
            </button>
            <button 
              onClick={() => {
                // Quick shortcut list App Drawer simulation toggler
                const options: Array<typeof activeAndroidScreen> = ["dipti", "whatsapp", "music"];
                const nextScreenIdx = (options.indexOf(activeAndroidScreen) + 1) % options.length;
                setAndroidScreen(options[nextScreenIdx]);
              }}
              title="Simulator App Switcher button"
              className="p-2 hover:bg-slate-900 hover:text-white rounded-lg transition"
            >
              <span className="w-3.5 h-3.5 block rounded-xs border-2 border-current" />
            </button>
          </div>

        </section>

        {/* RIGHT PANEL: Live Speech Transcription & Persisted references library */}
        <section className="lg:col-span-4 flex flex-col bg-slate-950/40 backdrop-blur-md rounded-2xl border border-slate-800/60 p-5 self-stretch overflow-hidden max-h-[640px] lg:max-h-none">
          
          {/* Tab Navigation header */}
          <div className="flex border-b border-slate-800 mb-4 pb-2 justify-between items-center">
            <div className="flex gap-1">
              <button
                onClick={() => setCurrentTab("chat")}
                className={`text-[11px] font-semibold px-2 py-1.5 rounded-md transition ${currentTab === "chat" ? "bg-slate-800 text-cyan-400" : "text-slate-400 hover:bg-slate-900"}`}
              >
                Live Turn
              </button>
              <button
                onClick={() => setCurrentTab("database")}
                className={`text-[11px] font-semibold px-2 py-1.5 rounded-md transition flex items-center gap-1 ${currentTab === "database" ? "bg-slate-800 text-cyan-400" : "text-slate-400 hover:bg-slate-900"}`}
              >
                <Database className="w-3 h-3" />
                Dipti DB
              </button>
              <button
                onClick={() => setCurrentTab("intents")}
                className={`text-[11px] font-semibold px-2 py-1.5 rounded-md transition ${currentTab === "intents" ? "bg-slate-800 text-cyan-400" : "text-slate-400 hover:bg-slate-900"}`}
              >
                Intents ({intentLogs.length - 1})
              </button>
            </div>
            
            {/* Trash button to wipe histories */}
            <button
              onClick={handleResetDb}
              title="Clear Database history"
              className="text-slate-500 hover:text-rose-400 p-1 hover:bg-slate-900 rounded transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* TAB 1: Chat Voice-to-Voice Tracings */}
          {currentTab === "chat" && (
            <div className="flex-1 flex flex-col overflow-hidden min-h-[300px]">
              
              {/* Transcription Area wrapper */}
              <div 
                ref={scrollRef}
                className="flex-1 overflow-y-auto space-y-3.5 pr-1 text-xs"
              >
                {pastConversations.length === 0 && !currentInputText && !currentOutputText && (
                  <div className="h-full flex flex-col items-center justify-center text-center p-4">
                    <Activity className="w-8 h-8 text-slate-700 mb-2 animate-pulse" />
                    <p className="text-slate-400 text-center max-w-[200px]">No active Speech transcription logged. Click the Orb to stream dialogs!</p>
                  </div>
                )}

                {/* Print historical database values */}
                {pastConversations.map((c) => (
                  <div 
                    key={c.id} 
                    className={`flex flex-col gap-1 max-w-[85%] ${c.role === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'}`}
                  >
                    <span className="text-[9px] text-slate-550 font-mono">
                      {new Date(c.timestamp).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' })}
                    </span>
                    <div className={`p-3 rounded-2xl ${c.role === 'user' ? 'bg-cyan-500/10 border border-cyan-500/20 text-slate-100 rounded-tr-none' : 'bg-slate-900/80 border border-slate-800 text-slate-300 rounded-tl-none'}`}>
                      <p>{c.text}</p>
                    </div>
                  </div>
                ))}

                {/* Print dynamic real-time speech results */}
                {currentInputText && (
                  <div className="flex flex-col gap-1 max-w-[85%] ml-auto items-end">
                    <span className="text-[9px] text-cyan-400 font-mono flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                      USER SPEAKING
                    </span>
                    <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-400/30 text-white rounded-tr-none shadow-[0_0_10px_rgba(6,182,212,0.1)]">
                      <p>{currentInputText}</p>
                    </div>
                  </div>
                )}

                {currentOutputText && (
                  <div className="flex flex-col gap-1 max-w-[85%] mr-auto items-start">
                    <span className="text-[9px] text-emerald-400 font-mono flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      DIPTI SPEAKING
                    </span>
                    <div className="p-3 rounded-2xl bg-emerald-950/20 border border-emerald-400/30 text-slate-100 rounded-tl-none shadow-[0_0_10px_rgba(52,211,153,0.1)]">
                      <p>{currentOutputText}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Language selection panel at footer */}
              <div className="mt-3 pt-3 border-t border-slate-800/85 grid grid-cols-4 gap-1">
                {(["detect", "hi", "as", "en"] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => {
                      setLanguage(lang);
                      alert(`Assigned Assistant listener format parameters targetting: [${lang.toUpperCase()}] mode.`);
                    }}
                    className={`py-1 rounded text-[10px] font-semibold uppercase transition flex items-center justify-center ${selectedLanguage === lang ? 'bg-cyan-500 text-black' : 'bg-slate-900/60 text-slate-400 hover:text-white'}`}
                  >
                    {lang === "detect" ? "AUTO" : lang}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: Persistent Local Database references */}
          {currentTab === "database" && (
            <div className="flex-1 flex flex-col overflow-hidden min-h-[300px]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase">Knowledge Base References</span>
                <button
                  onClick={() => setShowAddRefModal(true)}
                  className="bg-cyan-500 hover:bg-cyan-400 text-black px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer font-sans"
                >
                  <Plus className="w-3 h-3" />
                  Add Note
                </button>
              </div>

              {/* Scrollable reference notes list */}
              <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 text-xs">
                {references.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-4">
                    <Database className="w-7 h-7 text-slate-800 mb-2" />
                    <p className="text-slate-500 text-xs text-center">Your companion reference library is empty. Add notes manually or ask Dipti to write facts!</p>
                  </div>
                ) : (
                  references.map((ref) => (
                    <div key={ref.id} className="p-3 bg-slate-900/50 border border-slate-800 rounded-lg relative hover:border-slate-700 transition">
                      <button
                        onClick={() => deleteReferenceCard(ref.id)}
                        className="absolute top-2 right-2 text-slate-550 hover:text-rose-450"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      
                      <div className="flex gap-2 items-center mb-1">
                        <span className="bg-slate-800 text-[9px] px-1.5 py-0.5 rounded font-mono text-cyan-400 border border-cyan-900/30">
                          {ref.category}
                        </span>
                        <h4 className="font-semibold text-slate-200 select-all pr-5">{ref.title}</h4>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed whitespace-pre-line py-1 border-b border-slate-800/20">{ref.content}</p>
                      
                      <div className="mt-1 flex items-center justify-between text-[9px] text-slate-550 font-mono">
                        <span>Database Node Ref</span>
                        <span>{new Date(ref.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: Android Intents Logs Terminal */}
          {currentTab === "intents" && (
            <div className="flex-1 flex flex-col overflow-hidden min-h-[300px]">
              <div className="bg-black/40 border border-slate-800 p-2 rounded-t-lg flex items-center justify-between bg-zinc-950">
                <span className="font-mono text-[10px] text-slate-400">@Android_Logcat_Tuner</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </div>
              <div className="flex-1 overflow-y-auto bg-black p-3 rounded-b-lg font-mono text-[10px] space-y-2 pr-1 select-all select-none">
                {intentLogs.map((log) => (
                  <div key={log.id} className="pb-2 border-b border-slate-900">
                    <div className="flex justify-between text-slate-500">
                      <span>[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                      <span className={log.status === "executed" ? "text-emerald-400" : "text-rose-400"}>
                        {log.status.toUpperCase()}
                      </span>
                    </div>
                    <div className="text-cyan-400 font-bold break-all">{log.action}</div>
                    {log.packageName && (
                      <div className="text-purple-400">pkg: {log.packageName}</div>
                    )}
                    {log.dataUrl && (
                      <div className="text-amber-400 underline truncate">uri: {log.dataUrl}</div>
                    )}
                    {log.extras && (
                      <div className="text-slate-300 pl-2 bg-slate-900/40 py-1 rounded mt-1">
                        <strong>Extras:</strong> {JSON.stringify(log.extras)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      </div>

      {/* FOOTER */}
      <footer className="relative z-10 text-[11px] text-slate-500 mt-12 text-center select-none py-4 border-t border-slate-900/60 w-full max-w-6xl flex flex-col md:flex-row items-center justify-between gap-3">
        <p>
          Designed for Android WebView integration. Powered by advanced custom server-side <strong>gemini-3.1-flash-live-preview</strong>.
        </p>
        <p>
          Configure your secrets using <strong>Settings &gt; Secrets</strong> panel.
        </p>
      </footer>

      {/* DIALOG POPUP: Add Memory Reference manually */}
      <AnimatePresence>
        {showAddRefModal && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-950 border border-slate-800 rounded-xl p-5 w-full max-w-md"
            >
              <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-800">
                <h3 className="font-bold text-slate-200">Save Data Reference Node</h3>
                <button
                  onClick={() => setShowAddRefModal(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <Plus className="w-5 h-5 rotate-45" />
                </button>
              </div>

              <form onSubmit={handleManualAddRef} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Title / Fact Identifier</label>
                  <input
                    type="text"
                    required
                    value={refTitle}
                    onChange={(e) => setRefTitle(e.target.value)}
                    placeholder="e.g. My Dentist Number"
                    className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Classification Category</label>
                  <select
                    value={refCategory}
                    onChange={(e) => setRefCategory(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="general">General Memory</option>
                    <option value="note">Secret Note</option>
                    <option value="reminder">Scheduled Reminder</option>
                    <option value="link">Web Document/Link</option>
                    <option value="contact">Personal Contact</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Detailed Content</label>
                  <textarea
                    required
                    rows={4}
                    value={refContent}
                    onChange={(e) => setRefContent(e.target.value)}
                    placeholder="Provide specific notes or reference values Dipti should recall..."
                    className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-xs text-white focus:outline-none focus:border-cyan-500 resize-none"
                  />
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddRefModal(false)}
                    className="bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-1.5 rounded text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-cyan-500 hover:bg-cyan-400 text-black px-4 py-1.5 rounded text-xs font-bold"
                  >
                    Commit to Database
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
