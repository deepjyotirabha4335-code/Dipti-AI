export class AudioStreamer {
  private audioCtx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private onAudioChunk: (base64Audio: string, rawVolume: number) => void;

  constructor(onAudioChunk: (base64Audio: string, rawVolume: number) => void) {
    this.onAudioChunk = onAudioChunk;
  }

  public async start(): Promise<void> {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      // Directly create AudioContext at 16kHz - browser handles quality downsampling automatically
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass({ sampleRate: 16000 });

      this.source = this.audioCtx.createMediaStreamSource(this.stream);
      
      // BufferSize 4096 is optimal for low-latency non-blocking streaming
      this.processor = this.audioCtx.createScriptProcessor(4096, 1, 1);

      this.source.connect(this.processor);
      this.processor.connect(this.audioCtx.destination);

      this.processor.onaudioprocess = (e) => {
        if (!this.audioCtx || this.audioCtx.state === "closed") return;

        const channelData = e.inputBuffer.getChannelData(0);
        
        // Calculate root-mean-square volume for neon animated orb visualizer
        let sum = 0;
        for (let i = 0; i < channelData.length; i++) {
          sum += channelData[i] * channelData[i];
        }
        const rms = Math.sqrt(sum / channelData.length);
        const volumeFactor = Math.min(1, rms * 5); // scale volume nicely

        const pcm16 = this.float32ToPcm16(channelData);
        const base64 = this.arrayBufferToBase64(pcm16.buffer);

        if (base64.length > 0) {
          this.onAudioChunk(base64, volumeFactor);
        }
      };

    } catch (err) {
      console.error("AudioStreamer failed to access microphone:", err);
      throw err;
    }
  }

  public stop(): void {
    if (this.processor) {
      this.processor.disconnect();
      this.processor.onaudioprocess = null;
      this.processor = null;
    }

    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }

    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }

    if (this.audioCtx) {
      this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }
  }

  private float32ToPcm16(floatData: Float32Array): Int16Array {
    const pcmData = new Int16Array(floatData.length);
    for (let i = 0; i < floatData.length; i++) {
      const s = Math.max(-1.0, Math.min(1.0, floatData[i]));
      // Clamp and map properly to 16-bit signed integer range
      pcmData[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return pcmData;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
}
