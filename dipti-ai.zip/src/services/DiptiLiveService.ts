import { useDiptiStore } from "../store/diptiStore";
import { AudioStreamer } from "./AudioStreamer";
import { AudioPlayer } from "./AudioPlayer";
import { AndroidBridge } from "../utils/AndroidBridge";
import { ConversationTurn } from "../types";

export class DiptiLiveService {
  private socket: WebSocket | null = null;
  private streamer: AudioStreamer | null = null;
  private player: AudioPlayer | null = null;
  private activeOutputTranscript = "";

  public async connect(): Promise<void> {
    const store = useDiptiStore.getState();
    store.setDiptiState("connecting");

    // Retrieve active browser location host (supports full port range on our container proxy)
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const socketUrl = `${protocol}//${window.location.host}/live`;

    console.log(`Connecting system socket to: ${socketUrl}`);
    this.socket = new WebSocket(socketUrl);

    this.player = new AudioPlayer((vol) => {
      useDiptiStore.getState().setOutputVolume(vol);
      if (vol > 0.05) {
        useDiptiStore.getState().setDiptiState("speaking");
      } else {
        // If connected and playing but volume drops, fall back to thinking or listening
        const currentState = useDiptiStore.getState().diptiState;
        if (currentState === "speaking") {
          useDiptiStore.getState().setDiptiState("listening");
        }
      }
    });

    this.socket.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data);

        // Status update from Server's Gemini session
        if (msg.type === "status" && msg.status === "ready") {
          console.log("Gemini session ready. Unlocking Audio Mic stream.");
          store.setConnected(true);
          store.setDiptiState("listening");

          this.streamer = new AudioStreamer((audioBase64, micVolume) => {
            useDiptiStore.getState().setInputVolume(micVolume);
            
            // Toggle active state to listening while user speaks
            if (micVolume > 0.1) {
              const currentS = useDiptiStore.getState().diptiState;
              if (currentS !== "listening" && currentS !== "thinking" && currentS !== "speaking") {
                useDiptiStore.getState().setDiptiState("listening");
              }
            }

            // Stream base64 audio directly to Express Server -> Gemini Live session
            if (this.socket && this.socket.readyState === WebSocket.OPEN) {
              this.socket.send(JSON.stringify({ audio: audioBase64 }));
            }
          });

          await this.streamer.start();
        }

        // Playback raw audio received (Model responds at 24kHz)
        if (msg.type === "audio" && msg.audio) {
          this.player?.playChunk(msg.audio);
        }

        // Handle vocal interruption (User spoke over Dipti)
        if (msg.type === "interrupted") {
          console.log("Interruption signal received. Halting speech outputs.");
          this.player?.interrupt();
          store.setDiptiState("listening");
          this.activeOutputTranscript = "";
          store.setCurrentOutputText("");
        }

        // Live transcription updates (natively calculated by Gemini in the cloud)
        if (msg.type === "userTranscript" && msg.text) {
          store.setCurrentInputText(msg.text);
          store.setDiptiState("thinking");
          
          if (msg.turn) {
            store.addConversationTurn(msg.turn);
          } else {
            // Memory layout fallback
            const fakeTurn: ConversationTurn = {
              id: `user-${Date.now()}`,
              timestamp: new Date().toISOString(),
              role: "user",
              mediaType: "voice",
              text: msg.text
            };
            store.addConversationTurn(fakeTurn);
          }
        }

        if (msg.type === "modelTranscript" && msg.text) {
          this.activeOutputTranscript += msg.text;
          store.setCurrentOutputText(this.activeOutputTranscript);
          
          // When a chunk arrives, we can assume Dipti is preparing/speaking
          store.setDiptiState("speaking");
        }

        if (msg.type === "modelTurnSaved" && msg.turn) {
          console.log("Model turn completed and successfully written to server DB.");
          store.addConversationTurn(msg.turn);
          store.setCurrentOutputText("");
          this.activeOutputTranscript = "";
          store.fetchConversations();
        }

        // Handle triggers to write reference cards locally from server
        if (msg.type === "referenceAdded" && msg.data) {
          console.log("Local database captured memory reference update.");
          store.fetchReferences();
        }

        // Handle secure Android Tool Executions via Bridge
        if (msg.type === "toolCall" && msg.functionCalls) {
          store.setDiptiState("thinking");
          const functionCalls = msg.functionCalls;
          
          for (const func of functionCalls) {
            const bridge = new AndroidBridge(
              store.permissionState,
              (log) => store.addIntentLog(log)
            );

            let resultOutput = "";
            const args = func.args || {};

            console.log(`Executing tool on bridge: ${func.name} with args:`, args);

            // Mapping tool declarations onto bridge invocations
            if (func.name === "openApp") {
              resultOutput = bridge.openApp(args.appName);
            } else if (func.name === "openWebsite") {
              resultOutput = bridge.openWebsite(args.url);
            } else if (func.name === "searchGoogle") {
              resultOutput = bridge.searchGoogle(args.query);
            } else if (func.name === "openYouTube") {
              resultOutput = bridge.openYouTube(args.query);
            } else if (func.name === "openMaps") {
              resultOutput = bridge.openMaps(args.location);
            } else if (func.name === "makeCall") {
              resultOutput = bridge.makeCall(args.phoneNumber);
            } else if (func.name === "sendSMS") {
              resultOutput = bridge.sendSMS(args.number, args.message);
            } else if (func.name === "sendWhatsAppMessage") {
              resultOutput = bridge.sendWhatsAppMessage(args.recipient, args.message);
            } else if (func.name === "playMusic") {
              resultOutput = bridge.playMusic(args.trackName);
            } else if (func.name === "pauseMusic") {
              resultOutput = bridge.pauseMusic();
            } else if (func.name === "setAlarm") {
              resultOutput = bridge.setAlarm(args.time);
            } else if (func.name === "openSettings") {
              resultOutput = bridge.openSettings();
            } else if (func.name === "copyText") {
              resultOutput = bridge.copyText(args.content);
            } else if (func.name === "shareContent") {
              resultOutput = bridge.shareContent(args.content);
            } else if (func.name === "readNotifications") {
              const notifications = bridge.readNotifications();
              resultOutput = JSON.stringify({ active_notifications: notifications });
            } else if (func.name === "getInstalledApps") {
              const appsList = bridge.getInstalledApps();
              resultOutput = JSON.stringify({ installed_apps: appsList });
            } else if (func.name === "addReference") {
              // This tool saves notes and database logs. Returns ok, server handles the local DB save.
              resultOutput = `Successfully stored fact/memory card: "${args.title}" categorized as ${args.category}.`;
            } else {
              resultOutput = `Error: Unsupported tool name "${func.name}".`;
            }

            // After execution logs, register complete conversation turn from Dipti summarizing her action
            const modelLog: ConversationTurn = {
              id: `model-${Date.now()}`,
              timestamp: new Date().toISOString(),
              role: "model",
              mediaType: "text",
              text: `Executed device function: [${func.name}] with results: ${resultOutput}`
            };
            store.addConversationTurn(modelLog);

            // Send tool result back to websocket to keep Gemini updated
            if (this.socket && this.socket.readyState === WebSocket.OPEN) {
              this.socket.send(JSON.stringify({
                type: "toolResponse",
                functionResponses: [
                  {
                    name: func.name,
                    response: { output: resultOutput },
                    id: func.id
                  }
                ],
                toolDetails: {
                  name: func.name,
                  args: func.args
                }
              }));
            }
          }
        }

        // Capture general error feedback
        if (msg.type === "error") {
          console.error("Gemini live stream reported error:", msg.error);
          this.disconnect();
        }

      } catch (err) {
        console.error("Error breaking down server socket event:", err);
      }
    };

    this.socket.onclose = () => {
      console.log("WebSocket connection closed.");
      this.disconnect();
    };

    this.socket.onerror = (err) => {
      console.error("WebSocket transport error:", err);
      this.disconnect();
    };
  }

  public disconnect(): void {
    const store = useDiptiStore.getState();
    store.setConnected(false);
    store.setDiptiState("disconnected");
    store.setInputVolume(0);
    store.setOutputVolume(0);
    store.setCurrentInputText("");
    store.setCurrentOutputText("");
    this.activeOutputTranscript = "";

    if (this.streamer) {
      this.streamer.stop();
      this.streamer = null;
    }

    if (this.player) {
      this.player.close();
      this.player = null;
    }

    if (this.socket) {
      try {
        this.socket.close();
      } catch (e) {}
      this.socket = null;
    }

    console.log("Dipti session fully deallocated.");
  }
}
