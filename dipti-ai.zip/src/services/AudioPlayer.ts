export class AudioPlayer {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private nextStartTime: number = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private onVolumeChange?: (volume: number) => void;
  private volumeInterval: any = null;

  constructor(onVolumeChange?: (volume: number) => void) {
    this.onVolumeChange = onVolumeChange;
  }

  public init(): void {
    if (this.audioCtx) return;

    const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
    // Model replies exclusively at 24kHz sample rate
    this.audioCtx = new AudioCtxClass({ sampleRate: 24000 });
    this.analyser = this.audioCtx.createAnalyser();
    this.analyser.fftSize = 256;
    this.analyser.connect(this.audioCtx.destination);

    // Dynamic frequency reporting loop for speaker animation
    if (this.onVolumeChange) {
      const dbArr = new Uint8Array(this.analyser.frequencyBinCount);
      this.volumeInterval = setInterval(() => {
        if (!this.analyser || !this.audioCtx || this.audioCtx.state === "closed") return;
        this.analyser.getByteFrequencyData(dbArr);
        let sum = 0;
        for (let i = 0; i < dbArr.length; i++) {
          sum += dbArr[i];
        }
        const avg = sum / dbArr.length;
        // Normalised value between 0.0 and 1.0
        this.onVolumeChange?.(Math.min(1, avg / 128));
      }, 50);
    }
  }

  public playChunk(base64PCM: string): void {
    this.init();
    
    if (!this.audioCtx || !this.analyser) return;

    try {
      // Fast base64 raw binary string decoding
      const raw = window.atob(base64PCM);
      const arrayBuffer = new ArrayBuffer(raw.length);
      const byteView = new Uint8Array(arrayBuffer);
      for (let i = 0; i < raw.length; i++) {
        byteView[i] = raw.charCodeAt(i);
      }

      // Read Int16 values mapping to native Web Audio float amplitude (-1 to 1)
      const int16Array = new Int16Array(arrayBuffer);
      const float32Array = new Float32Array(int16Array.length);
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 0x8000;
      }

      const audioBuffer = this.audioCtx.createBuffer(1, float32Array.length, 24000);
      audioBuffer.getChannelData(0).set(float32Array);

      const source = this.audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.analyser);

      const currentTime = this.audioCtx.currentTime;
      // Precision gapless queue scheduling preventing gaps or overlaps from internet jitter
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime + 0.04; // 40ms safety buffer
      }

      source.start(this.nextStartTime);
      this.activeSources.push(source);

      // Clean source referencing once finished playing
      source.onended = () => {
        this.activeSources = this.activeSources.filter(s => s !== source);
      };

      this.nextStartTime += audioBuffer.duration;

    } catch (err) {
      console.error("AudioPlayer failed to play audio chunk:", err);
    }
  }

  public interrupt(): void {
    console.log("AudioPlayer: Interrupting vocal stream playback.");
    // Stop all active audio buffer nodes instantly
    this.activeSources.forEach((src) => {
      try {
        src.stop();
      } catch (err) {
        // Source may have already stopped naturally
      }
    });

    this.activeSources = [];
    this.nextStartTime = 0;
    this.onVolumeChange?.(0);
  }

  public close(): void {
    this.interrupt();
    if (this.volumeInterval) {
      clearInterval(this.volumeInterval);
      this.volumeInterval = null;
    }
    if (this.audioCtx) {
      this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }
    this.analyser = null;
  }
}
