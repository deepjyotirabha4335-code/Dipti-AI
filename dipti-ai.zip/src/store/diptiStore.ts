import { create } from "zustand";
import { 
  DiptiState, 
  ConversationTurn, 
  ReferenceItem, 
  AndroidIntentLog, 
  AndroidPermissionState,
  WhatsAppChat,
  MusicTrack
} from "../types";
import { SynthMusic } from "../utils/SynthMusic";

// Singleton client-side synthesizer for browser song playback
let synth: SynthMusic | null = null;

interface DiptiStore {
  diptiState: DiptiState;
  isConnected: boolean;
  inputVolume: number;
  outputVolume: number;
  permissionState: AndroidPermissionState;
  intentLogs: AndroidIntentLog[];
  pastConversations: ConversationTurn[];
  references: ReferenceItem[];
  currentInputText: string;
  currentOutputText: string;
  selectedLanguage: string;

  // NEW: WhatsApp Simulation State
  activeAndroidScreen: "dipti" | "whatsapp" | "music";
  whatsappChats: WhatsAppChat[];
  activeWhatsAppChatId: string;

  // NEW: Music Player Simulation State
  musicPlaying: boolean;
  currentTrackIndex: number;
  musicProgressStep: number;
  tracks: MusicTrack[];

  // Actions
  setDiptiState: (state: DiptiState) => void;
  setConnected: (connected: boolean) => void;
  setInputVolume: (vol: number) => void;
  setOutputVolume: (vol: number) => void;
  togglePermission: (key: keyof AndroidPermissionState) => void;
  addIntentLog: (log: AndroidIntentLog) => void;
  addConversationTurn: (turn: ConversationTurn) => void;
  setLanguage: (lang: string) => void;
  setCurrentInputText: (text: string) => void;
  setCurrentOutputText: (text: string) => void;

  // NEW: WhatsApp actions
  setAndroidScreen: (screen: "dipti" | "whatsapp" | "music") => void;
  setActiveWhatsAppChat: (id: string) => void;
  sendWhatsAppMessage: (chatId: string, text: string, sender: 'user' | 'dipti' | 'contact') => void;

  // NEW: Music Actions
  playMusic: (trackId?: string) => string;
  pauseMusic: () => string;
  nextTrack: () => string;
  prevTrack: () => string;

  // Database persistence actions syncing with ServerDb
  fetchConversations: () => Promise<void>;
  fetchReferences: () => Promise<void>;
  addReferenceCard: (title: string, content: string, category: string) => Promise<void>;
  deleteReferenceCard: (id: string) => Promise<void>;
  clearConversationHistory: () => Promise<void>;
}

export const useDiptiStore = create<DiptiStore>((set, get) => ({
  diptiState: "disconnected",
  isConnected: false,
  inputVolume: 0,
  outputVolume: 0,
  permissionState: {
    microphone: true,
    phone_calls: true,
    sms: true,
    notifications: true,
    alarms: true,
    contacts: true,
  },
  intentLogs: [
    {
      id: "log-init",
      timestamp: new Date().toISOString(),
      action: "dipti.intent.action.BOOT_COMPLETED",
      status: "executed",
    }
  ],
  pastConversations: [],
  references: [],
  currentInputText: "",
  currentOutputText: "",
  selectedLanguage: "detect",

  // Simulated WhatsApp threads with preloaded Assamese/Hindi contexts
  activeAndroidScreen: "dipti",
  activeWhatsAppChatId: "chat-preeti",
  whatsappChats: [
    {
      id: "chat-preeti",
      contactName: "Preeti (Apun)",
      avatarColor: "bg-emerald-500",
      lastMessageTime: "14:48 PM",
      messages: [
        { id: "m1", sender: "contact", text: "কি খবৰ দীপ্তি? (What's news Dipti?)", timestamp: "14:45" },
        { id: "m2", sender: "contact", text: "Are you online tonight? Need to ask something.", timestamp: "14:46" },
        { id: "m3", sender: "dipti", text: "ভালেই আপোন! মই সদায় তোমাৰ সহায় কৰিবলৈ সাজু আছোঁ। (Doing great! Always ready to help). Let me know!", timestamp: "14:48" }
      ]
    },
    {
      id: "chat-rahul",
      contactName: "Rahul (Guwahati)",
      avatarColor: "bg-indigo-500",
      lastMessageTime: "13:20 PM",
      messages: [
        { id: "mr1", sender: "contact", text: "Hey! Did you update the latest database parameters?", timestamp: "13:15" },
        { id: "mr2", sender: "user", text: "Yes, Dipti saved the reference contacts on Cloud storage.", timestamp: "13:20" }
      ]
    },
    {
      id: "chat-mumbai",
      contactName: "Amit (Bhaiya)",
      avatarColor: "bg-amber-500",
      lastMessageTime: "Yesterday",
      messages: [
        { id: "mam1", sender: "contact", text: "अरे भाई, शाम को घर जल्दी आ जाना। मम्मी खाना बना रही हैं।", timestamp: "Yesterday" }
      ]
    }
  ],

  // Music state preloads
  musicPlaying: false,
  currentTrackIndex: 0,
  musicProgressStep: 0,
  tracks: [
    { id: "bihu", title: "Joyful Assam Bihu", artist: "Monalisha Saikia", duration: 180, genre: "Folk Melody", notes: [440, 523] },
    { id: "lofi", title: "Bollywood Ambient Lofi", artist: "Arijit Beats", duration: 240, genre: "Slo-Fi Beats", notes: [261, 329] },
    { id: "dipti", title: "Dipti OS Chime Bell Theme", artist: "Android Synth Lab", duration: 120, genre: "Acoustic Bells", notes: [523, 784] }
  ],

  setDiptiState: (diptiState) => {
    set({ diptiState });
  },

  setConnected: (isConnected) => set({ isConnected }),

  setInputVolume: (inputVolume) => set({ inputVolume }),

  setOutputVolume: (outputVolume) => set({ outputVolume }),

  togglePermission: (key) => set((state) => ({
    permissionState: {
      ...state.permissionState,
      [key]: !state.permissionState[key],
    }
  })),

  addIntentLog: (log) => set((state) => ({
    intentLogs: [log, ...state.intentLogs].slice(0, 50),
  })),

  addConversationTurn: (turn) => set((state) => {
    const exists = state.pastConversations.some(t => t.id === turn.id);
    if (exists) return {};
    return {
      pastConversations: [...state.pastConversations, turn]
    };
  }),

  setLanguage: (selectedLanguage) => set({ selectedLanguage }),

  setCurrentInputText: (currentInputText) => set({ currentInputText }),

  setCurrentOutputText: (currentOutputText) => set({ currentOutputText }),

  // WhatsApp Actions
  setAndroidScreen: (screen) => set({ activeAndroidScreen: screen }),
  
  setActiveWhatsAppChat: (id) => set({ activeWhatsAppChatId: id }),

  sendWhatsAppMessage: (chatId, text, sender) => set((state) => {
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    
    const updatedChats = state.whatsappChats.map((c) => {
      if (c.id === chatId) {
        return {
          ...c,
          lastMessageTime: formattedTime,
          messages: [
            ...c.messages,
            {
              id: `wmsg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              sender,
              text,
              timestamp: formattedTime
            }
          ]
        };
      }
      return c;
    });

    return { whatsappChats: updatedChats };
  }),

  // Music Actions (Hooked to Browser Audio Synth)
  playMusic: (trackId) => {
    // Lazy instance initialization
    if (!synth) {
      synth = new SynthMusic((bStep) => {
        set({ musicProgressStep: bStep });
      });
    }

    const currentTracks = get().tracks;
    let trackIndex = get().currentTrackIndex;

    if (trackId) {
      const idx = currentTracks.findIndex(t => t.id === trackId || t.title.toLowerCase().includes(trackId.toLowerCase()));
      if (idx !== -1) {
        trackIndex = idx;
      }
    }

    const chosenTrack = currentTracks[trackIndex];
    synth.play(chosenTrack.id);

    set({ 
      musicPlaying: true, 
      currentTrackIndex: trackIndex,
      activeAndroidScreen: "music" // Automatically navigate user screen to player
    });

    return `Currently streaming synthetic track "${chosenTrack.title}" by ${chosenTrack.artist} on device native audio buffers.`;
  },

  pauseMusic: () => {
    if (synth) {
      synth.stop();
    }
    set({ musicPlaying: false });
    return "Soft-held native media elements paused successfully.";
  },

  nextTrack: () => {
    const nextIdx = (get().currentTrackIndex + 1) % get().tracks.length;
    set({ currentTrackIndex: nextIdx });
    get().playMusic();
    return `Skipped forward to track index ${nextIdx}.`;
  },

  prevTrack: () => {
    const tracksList = get().tracks;
    const prevIdx = (get().currentTrackIndex - 1 + tracksList.length) % tracksList.length;
    set({ currentTrackIndex: prevIdx });
    get().playMusic();
    return `Skipped back to track index ${prevIdx}.`;
  },

  // Database operations
  fetchConversations: async () => {
    try {
      const response = await fetch("/api/db/conversations");
      const res = await response.json();
      if (res.success) {
        set({ pastConversations: res.data });
      }
    } catch (e) {
      console.error("Failed to fetch past conversations:", e);
    }
  },

  fetchReferences: async () => {
    try {
      const response = await fetch("/api/db/references");
      const res = await response.json();
      if (res.success) {
        set({ references: res.data });
      }
    } catch (e) {
      console.error("Failed to fetch references:", e);
    }
  },

  addReferenceCard: async (title, content, category) => {
    try {
      const response = await fetch("/api/db/references", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content, category }),
      });
      const res = await response.json();
      if (res.success) {
        set((state) => ({
          references: [...state.references, res.data],
        }));
      }
    } catch (e) {
      console.error("Failed to save reference card:", e);
    }
  },

  deleteReferenceCard: async (id) => {
    try {
      const response = await fetch(`/api/db/references/${id}`, { method: "DELETE" });
      const res = await response.json();
      if (res.success) {
        set((state) => ({
          references: state.references.filter((ref) => ref.id !== id),
        }));
      }
    } catch (e) {
      console.error("Failed to delete reference:", e);
    }
  },

  clearConversationHistory: async () => {
    try {
      const response = await fetch("/api/db/clear", { method: "POST" });
      const res = await response.json();
      if (res.success) {
        set({ pastConversations: [], references: [] });
      }
    } catch (e) {
      console.error("Failed to clear database:", e);
    }
  },
}));

export type { DiptiStore };
