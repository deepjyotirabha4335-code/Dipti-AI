import { AndroidIntentLog, AndroidPermissionState } from "../types";
import { useDiptiStore } from "../store/diptiStore";

export class AndroidBridge {
  private logCallback: (log: AndroidIntentLog) => void;
  private permissionState: AndroidPermissionState;

  constructor(
    permissionState: AndroidPermissionState,
    logCallback: (log: AndroidIntentLog) => void
  ) {
    this.permissionState = permissionState;
    this.logCallback = logCallback;
  }

  private createLog(
    action: string,
    packageName?: string,
    dataUrl?: string,
    extras?: Record<string, string>,
    requiredPermission?: keyof AndroidPermissionState
  ): { allowed: boolean; log: AndroidIntentLog } {
    let allowed = true;
    if (requiredPermission && !this.permissionState[requiredPermission]) {
      allowed = false;
    }

    const log: AndroidIntentLog = {
      id: `intent-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      action,
      packageName,
      dataUrl,
      extras,
      status: allowed ? "executed" : "denied",
    };

    this.logCallback(log);
    return { allowed, log };
  }

  public openApp(appName: string): string {
    const appsMap: Record<string, string> = {
      whatsapp: "com.whatsapp",
      instagram: "com.instagram.android",
      youtube: "com.google.android.youtube",
      chrome: "com.android.chrome",
      maps: "com.google.android.apps.maps",
      gallery: "com.android.gallery3d",
      camera: "com.android.camera",
      settings: "com.android.settings",
      music: "com.android.music",
    };

    const cleanName = appName.toLowerCase().trim();
    const pkg = appsMap[cleanName] || `com.android.${cleanName}`;
    const intentAction = "android.intent.action.MAIN";

    this.createLog(intentAction, pkg, undefined, { appName });
    
    // Interactive screen switching inside the simulator
    const store = useDiptiStore.getState();
    if (cleanName === "whatsapp") {
      store.setAndroidScreen("whatsapp");
      return `Launched mock WhatsApp Messenger. Active simulated screen changed to WhatsApp interface.`;
    } else if (cleanName === "music" || cleanName === "musicplayer" || cleanName === "player") {
      store.setAndroidScreen("music");
      return `Launched mock Music Player. Active simulated screen changed to Music Player interface.`;
    } else if (cleanName === "dipti" || cleanName === "assistant" || cleanName === "home") {
      store.setAndroidScreen("dipti");
      return `Launched default vocal assistant board.`;
    }

    // Simulate standard browser links
    if (cleanName === 'youtube') {
      window.open("https://www.youtube.com", "_blank");
    } else if (cleanName === 'chrome' || cleanName === 'browser') {
      window.open("https://www.google.com", "_blank");
    } else if (cleanName === 'maps') {
      window.open("https://maps.google.com", "_blank");
    }

    return `Successfully broadcasted Intent ACTION_MAIN for app package ${pkg} to launch ${appName}.`;
  }

  public openWebsite(url: string): string {
    let finalUrl = url;
    if (!/^https?:\/\//i.test(url)) {
      finalUrl = 'https://' + url;
    }
    this.createLog("android.intent.action.VIEW", "com.android.chrome", finalUrl);
    window.open(finalUrl, "_blank");
    return `Launched Web Browser Intent viewing webpage: ${finalUrl}`;
  }

  public searchGoogle(query: string): string {
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    this.createLog("android.intent.action.WEB_SEARCH", "com.android.chrome", searchUrl, { query });
    window.open(searchUrl, "_blank");
    return `Launched Google Web Search Intent for query: "${query}"`;
  }

  public openYouTube(query: string): string {
    const ytUrl = query 
      ? `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
      : "https://www.youtube.com";
    this.createLog("android.intent.action.VIEW", "com.google.android.youtube", ytUrl, { search: query });
    window.open(ytUrl, "_blank");
    return `Opened YouTube Intent search results for: "${query || 'Home'}"`;
  }

  public openMaps(location: string): string {
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`;
    this.createLog("android.intent.action.VIEW", "com.google.android.apps.maps", mapsUrl, { destination: location });
    window.open(mapsUrl, "_blank");
    return `Initiated Google Maps intent to locate Nav destination: "${location}"`;
  }

  public makeCall(phoneNumber: string): string {
    const { allowed } = this.createLog(
      "android.intent.action.CALL",
      "com.android.server.telecom",
      `tel:${phoneNumber}`,
      { phone: phoneNumber },
      "phone_calls"
    );

    if (!allowed) {
      return `PERMISSION_DENIED: Dipti requested call to "${phoneNumber}" but Android Phone Permission was rejected.`;
    }
    
    return `Successfully dialled Android dialer with action android.intent.action.CALL to line: ${phoneNumber}. Connection live.`;
  }

  public sendSMS(number: string, message: string): string {
    const { allowed } = this.createLog(
      "android.intent.action.SENDTO",
      "com.android.mms",
      `smsto:${number}`,
      { number, message },
      "sms"
    );

    if (!allowed) {
      return `PERMISSION_DENIED: Dipti requested sending SMS to "${number}" but SMS Permission was rejected.`;
    }

    return `Securely transmitted message body to ${number}: "${message}" via Android Telephony Manager.`;
  }

  // ADVANCED WHATSAPP AUTOMATION
  public sendWhatsAppMessage(recipient: string, message: string): string {
    // Check SMS or contact permissions as an equivalent gate for notifications / messaging
    const { allowed } = this.createLog(
      "com.whatsapp.intent.action.SEND_MSG",
      "com.whatsapp",
      undefined,
      { recipient, message },
      "sms"
    );

    if (!allowed) {
      return `PERMISSION_DENIED: WhatsApp automation requested but simulated SMS/Messaging Permission Shield is blocked.`;
    }

    const store = useDiptiStore.getState();
    const cleanRec = recipient.toLowerCase();
    
    // Attempt to locate matching chat thread
    let targetChatId = store.activeWhatsAppChatId;
    if (cleanRec.includes("preet") || cleanRec.includes("apun")) {
      targetChatId = "chat-preeti";
    } else if (cleanRec.includes("rahul") || cleanRec.includes("guwa")) {
      targetChatId = "chat-rahul";
    } else if (cleanRec.includes("amit") || cleanRec.includes("bhai")) {
      targetChatId = "chat-mumbai";
    }

    // Append message to store
    store.sendWhatsAppMessage(targetChatId, message, "dipti");
    store.setAndroidScreen("whatsapp");
    store.setActiveWhatsAppChat(targetChatId);

    return `WhatsApp message injected successfully to thread "${recipient}" saying: "${message}". Device updated actively.`;
  }

  // ADVANCED NATIVE MUSIC TRACKING CONTROLS
  public playMusic(trackName?: string): string {
    const store = useDiptiStore.getState();
    const result = store.playMusic(trackName);

    this.createLog(
      "android.intent.action.MEDIA_BUTTON",
      "com.android.music",
      undefined,
      { command: "play", trackName: trackName || "current" }
    );

    return result;
  }

  public pauseMusic(): string {
    const store = useDiptiStore.getState();
    const result = store.pauseMusic();

    this.createLog(
      "android.intent.action.MEDIA_BUTTON",
      "com.android.music",
      undefined,
      { command: "pause" }
    );

    return result;
  }

  public setAlarm(time: string): string {
    const { allowed } = this.createLog(
      "android.intent.action.SET_ALARM",
      "com.android.deskclock",
      undefined,
      { time },
      "alarms"
    );

    if (!allowed) {
      return `PERMISSION_DENIED: Alarm scheduler permission is disabled. Set Alarm for ${time} was aborted.`;
    }

    return `Alarm registered. Android Desk Clock scheduled a periodic wake alert for ${time}.`;
  }

  public openSettings(): string {
    this.createLog("android.settings.SETTINGS", "com.android.settings");
    return "Laid out simulated Android Settings pane.";
  }

  public copyText(content: string): string {
    try {
      navigator.clipboard.writeText(content);
      this.createLog("android.content.CLIPBOARD_SERVICE", undefined, undefined, { length: String(content.length) });
      return `Copied content of ${content.length} characters successfully to Android clipboard buffers.`;
    } catch (e) {
      return `Failed to write copy-buffer: ${String(e)}`;
    }
  }

  public shareContent(content: string): string {
    this.createLog("android.intent.action.SEND", undefined, undefined, { mimeType: "text/plain", data: content });
    
    if (navigator.share) {
      navigator.share({ text: content }).catch(() => {});
    }
    
    return `Launched Android Native Sharesheet containing content: "${content}"`;
  }

  public readNotifications(): string[] {
    const { allowed } = this.createLog(
      "android.service.notification.NotificationListenerService",
      "com.android.systemui",
      undefined,
      undefined,
      "notifications"
    );

    if (!allowed) {
      return ["PERMISSION_DENIED: Dipti lacks ACCESS_NOTIFICATION_POLICY. Real notifications cannot be read."];
    }

    return [
      "[WA] Preeti: 'কি খবর দীপ্তি? (What's news Dipti?) Are you online tonight?'",
      "[Gmail] Android System: 'Sync fully completed. 4 references updated.'",
      "[SMS] SBI-Alert: 'Your OTP for transaction request is 982341. Do not share.'",
      "[Insta] rahul_b: 'Liked your voice status. Awesome companion!'"
    ];
  }

  public getInstalledApps(): string[] {
    this.createLog("android.content.pm.PackageManager", "com.android.systemui");
    return [
      "WhatsApp (com.whatsapp)",
      "Instagram (com.instagram.android)",
      "YouTube (com.google.android.youtube)",
      "Chrome (com.android.chrome)",
      "Maps (com.google.android.apps.maps)",
      "Clock (com.android.deskclock)",
      "Settings (com.android.settings)",
      "Music Player (com.android.music)"
    ];
  }
}
