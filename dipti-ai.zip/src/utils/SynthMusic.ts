// Web Audio API custom synthesizer to play synthetic songs in client browser
export class SynthMusic {
  private ctx: AudioContext | null = null;
  private seqTimer: any = null;
  private currentTrackId: string = "";
  private step: number = 0;
  private onBeatCallback: (step: number) => void = () => {};

  constructor(onBeat: (step: number) => void) {
    this.onBeatCallback = onBeat;
  }

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  public play(trackId: string) {
    this.initCtx();
    this.stop(); // Stop any legacy tracker before booting new song

    this.currentTrackId = trackId;
    this.step = 0;

    // We can run a synthetic melody score step sequence
    const intervalMs = trackId === "bihu" ? 220 : trackId === "lofi" ? 350 : 280;

    const notesMap: Record<string, number[]> = {
      bihu: [440, 494, 523, 587, 659, 587, 659, 784, 880, 784, 659, 587, 523, 494, 440, 0], // pentatonic bihu-ish joyful upbeat
      lofi: [261, 329, 392, 494, 329, 392, 494, 587, 220, 261, 329, 392, 196, 246, 293, 0], // dreamy mellow chord arpeggio
      dipti: [523, 587, 659, 784, 880, 987, 1046, 0, 880, 784, 659, 523, 587, 0, 0, 0], // Dipti high-tech chime bells
    };

    const notes = notesMap[trackId] || notesMap.dipti;

    this.seqTimer = setInterval(() => {
      if (!this.ctx) return;
      const freq = notes[this.step % notes.length];
      
      if (freq > 0) {
        this.playTone(freq, trackId);
      }

      this.onBeatCallback(this.step % notes.length);
      this.step++;
    }, intervalMs);
  }

  private playTone(freq: number, trackId: string) {
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.frequency.value = freq;

      if (trackId === "bihu") {
        // flute style, triangle oscillator with small vib
        osc.type = "triangle";
        // smooth volume envelope
        gain.gain.setValueAtTime(0.01, this.ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.12, this.ctx.currentTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.22);
      } else if (trackId === "lofi") {
        // deep sub sine-wave pad style
        osc.type = "sine";
        gain.gain.setValueAtTime(0.01, this.ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.15, this.ctx.currentTime + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.45);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.5);
      } else {
        // chime style high pitch
        osc.type = "sine";
        gain.gain.setValueAtTime(0.01, this.ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.08, this.ctx.currentTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.4);
      }
    } catch (e) {
      console.warn("Synth voice allocation error:", e);
    }
  }

  public stop() {
    if (this.seqTimer) {
      clearInterval(this.seqTimer);
      this.seqTimer = null;
    }
  }
}
