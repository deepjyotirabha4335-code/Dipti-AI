import fs from 'fs';
import path from 'path';
import { ConversationTurn, ReferenceItem, DatabasePayload } from '../types';

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'db.json');

// Ensure database file exits with default empty state
function initDatabase(): DatabasePayload {
  const defaultDb: DatabasePayload = {
    conversations: [
      {
        id: 'welcome-message',
        timestamp: new Date().toISOString(),
        role: 'model',
        mediaType: 'text',
        text: 'नमस्ते! मॊइ दीप्ती बोलू आसु। मॊइ आपनार एंड्रॉइड साथी। (Hello! I am Dipti. I am your Android companion. Speak to me in Hindi, Assamese or English!)',
      }
    ],
    references: [
      {
        id: 'ref-default',
        createdAt: new Date().toISOString(),
        title: 'Dipti AI - Voice Companion Guide',
        content: 'Native Female voice assistant fluent in Hindi and Assamese. Supports real-time Android action automation such as making calls, setting alarms, and opening apps.',
        category: 'general'
      }
    ]
  };

  try {
    const dir = path.dirname(DB_FILE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    if (!fs.existsSync(DB_FILE_PATH)) {
      fs.writeFileSync(DB_FILE_PATH, JSON.stringify(defaultDb, null, 2), 'utf-8');
      return defaultDb;
    }

    const data = fs.readFileSync(DB_FILE_PATH, 'utf-8');
    const parsed = JSON.parse(data) as DatabasePayload;
    if (!parsed.conversations) parsed.conversations = [];
    if (!parsed.references) parsed.references = [];
    return parsed;
  } catch (error) {
    console.error('Failed to initialize database, using memory fallback:', error);
    return defaultDb;
  }
}

// Memory cache of DB
let dbCache: DatabasePayload = initDatabase();

function saveToDisk() {
  try {
    fs.writeFileSync(DB_FILE_PATH, JSON.stringify(dbCache, null, 2), 'utf-8');
  } catch (error) {
    console.error('Failed to save database to disk:', error);
  }
}

export const ServerDb = {
  getConversations(): ConversationTurn[] {
    return dbCache.conversations;
  },

  addConversation(turn: Omit<ConversationTurn, 'id' | 'timestamp'>): ConversationTurn {
    const newTurn: ConversationTurn = {
      ...turn,
      id: `turn-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };
    dbCache.conversations.push(newTurn);
    // Keep to max 100 entries for efficiency
    if (dbCache.conversations.length > 100) {
      dbCache.conversations.shift();
    }
    saveToDisk();
    return newTurn;
  },

  getReferences(): ReferenceItem[] {
    return dbCache.references;
  },

  addReference(item: Omit<ReferenceItem, 'id' | 'createdAt'>): ReferenceItem {
    const newItem: ReferenceItem = {
      ...item,
      id: `ref-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString()
    };
    dbCache.references.push(newItem);
    saveToDisk();
    return newItem;
  },

  removeReference(id: string): boolean {
    const index = dbCache.references.findIndex(ref => ref.id === id);
    if (index !== -1) {
      dbCache.references.splice(index, 1);
      saveToDisk();
      return true;
    }
    return false;
  },

  clearAll(): void {
    dbCache.conversations = [];
    dbCache.references = [];
    saveToDisk();
  }
};
