export type DiptiState = 'disconnected' | 'connecting' | 'listening' | 'thinking' | 'speaking';

export interface ConversationTurn {
  id: string;
  timestamp: string; // ISO string
  role: 'user' | 'model';
  mediaType: 'voice' | 'text';
  text: string;
  audioBase64?: string; // Opt-in raw or encoded representation
}

export interface ReferenceItem {
  id: string;
  createdAt: string;
  title: string;
  content: string;
  category: 'general' | 'note' | 'reminder' | 'link' | 'contact';
}

export interface AndroidIntentLog {
  id: string;
  timestamp: string;
  action: string;
  packageName?: string;
  dataUrl?: string;
  extras?: Record<string, string>;
  status: 'pending_permission' | 'executed' | 'denied';
}

export interface AndroidPermissionState {
  microphone: boolean;
  phone_calls: boolean;
  sms: boolean;
  notifications: boolean;
  alarms: boolean;
  contacts: boolean;
}

export interface DatabasePayload {
  conversations: ConversationTurn[];
  references: ReferenceItem[];
}

export interface WhatsAppMessage {
  id: string;
  sender: 'user' | 'contact' | 'dipti';
  text: string;
  timestamp: string;
}

export interface WhatsAppChat {
  id: string;
  contactName: string;
  avatarColor: string;
  messages: WhatsAppMessage[];
  lastMessageTime: string;
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  duration: number; // seconds
  genre: string;
  notes: number[]; // frequencies or simple MIDI offsets
}
