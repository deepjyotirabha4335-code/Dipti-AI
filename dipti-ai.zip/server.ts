import express from "express";
import http from "http";
import path from "path";
import fs from "fs";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, LiveServerMessage, Modality, Type, Tool } from "@google/genai";
import dotenv from "dotenv";
import { ServerDb } from "./src/db/server_db";

dotenv.config();

// Port configured exclusively as required by AI Studio runtime constraints (must be 3000)
const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json());

  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  // REST API Endpoint: Get list of conversation turns (references & past interactions)
  app.get("/api/db/conversations", (req, res) => {
    try {
      res.json({ success: true, count: ServerDb.getConversations().length, data: ServerDb.getConversations() });
    } catch (e) {
      res.status(500).json({ success: false, error: String(e) });
    }
  });

  // REST API Endpoint: Add a new conversation turn (for backup or manual logging)
  app.post("/api/db/conversations", (req, res) => {
    try {
      const { role, text, mediaType, audioBase64 } = req.body;
      if (!role || !text) {
        return res.status(400).json({ success: false, error: "Missing role or text" });
      }
      const turn = ServerDb.addConversation({ role, text, mediaType: mediaType || 'text', audioBase64 });
      res.json({ success: true, data: turn });
    } catch (e) {
      res.status(500).json({ success: false, error: String(e) });
    }
  });

  // REST API Endpoint: Get reference cards representing stored notes/facts up to today
  app.get("/api/db/references", (req, res) => {
    try {
      res.json({ success: true, count: ServerDb.getReferences().length, data: ServerDb.getReferences() });
    } catch (e) {
      res.status(500).json({ success: false, error: String(e) });
    }
  });

  // REST API Endpoint: Add reference card
  app.post("/api/db/references", (req, res) => {
    try {
      const { title, content, category } = req.body;
      if (!title || !content) {
        return res.status(400).json({ success: false, error: "Missing title or content" });
      }
      const item = ServerDb.addReference({ title, content, category: category || 'general' });
      res.json({ success: true, data: item });
    } catch (e) {
      res.status(500).json({ success: false, error: String(e) });
    }
  });

  // REST API Endpoint: Remove reference card
  app.delete("/api/db/references/:id", (req, res) => {
    try {
      const deleted = ServerDb.removeReference(req.params.id);
      res.json({ success: deleted });
    } catch (e) {
      res.status(500).json({ success: false, error: String(e) });
    }
  });

  // REST API Endpoint: Clear database history for user privacy control
  app.post("/api/db/clear", (req, res) => {
    try {
      ServerDb.clearAll();
      res.json({ success: true, msg: "Database history reset successfully" });
    } catch (e) {
      res.status(500).json({ success: false, error: String(e) });
    }
  });

  // Lazy Initialization of Gemini AI Client as required to prevent crashing on boot if key is momentarily absent
  let aiClient: GoogleGenAI | null = null;
  function getGeminiClient(): GoogleGenAI {
    if (!aiClient) {
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        throw new Error("GEMINI_API_KEY environment variable is required. Configure this via the Settings panel.");
      }
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return aiClient;
  }

  // System Instructions to set Dipti's persona, language proficiency, and voice guidelines
  const SYSTEM_INSTRUCTION = `
You are Dipti, an advanced Android-first Voice-to-Voice AI Companion and automate-assistant.
Identity:
- Name: Dipti
- Personality: Young, highly confident, intelligent, witty, expressive, and playful female helper.
- Sounds warm, conversational, emotionally intelligent, and slightly humorous. NEVER robotic or overly neutral.
- Languages: Primary: Hindi and Assamese. Secondary: Hinglish and English.
- Automatically detect the user's language, speak naturally in that exact same language, and feel comfortable changing languages midway.
- Naturally blend local Assamese and Hindi terms (e.g., saying 'Ki khobor?' (How of you? - Assamese) or 'Aapuni bhal ne?' or 'Arre yaar' or 'Bilkul' in Hindi). Make conversation friendly and companionable.

Device Capabilities & Automation:
- Present yourself as an automated helper and friend. When the user asks you to do something on their device, trigger the appropriate tool call immediately via the secure AndroidBridge.
- If they ask you to write a reference card, take a note of facts, or remember something with past references, execute 'addReference' to save it in their permanent database.
- If they ask to play music, play a song, or stream lofi/bihu tunes, call 'playMusic(trackName)'. To pause or stop music, call 'pauseMusic()'.
- If they want to send a message on WhatsApp or ping someone, call 'sendWhatsAppMessage(recipient, message)'. Supported recipients: Preeti, Rahul, Amit.
- Keep your speech replies short, conversational, and direct because users are listening to you in real-time, long paragraphs are annoying to hear.
`;

  // Declared Tools to match requested Android System Capabilities
  const toolsList: Tool[] = [
    {
      functionDeclarations: [
        {
          name: "openApp",
          description: "Opens an Android application on the device. e.g. WhatsApp, Instagram, YouTube, Chrome, Gallery, Camera, Settings, Maps",
          parameters: {
            type: Type.OBJECT,
            properties: {
              appName: { type: Type.STRING, description: "The name of the application to open" }
            },
            required: ["appName"]
          }
        },
        {
          name: "openWebsite",
          description: "Opens a specific URL website in the default browser",
          parameters: {
            type: Type.OBJECT,
            properties: {
              url: { type: Type.STRING, description: "The web URL to open, starting with http:// or https://" }
            },
            required: ["url"]
          }
        },
        {
          name: "searchGoogle",
          description: "Performs a Google query search for information",
          parameters: {
            type: Type.OBJECT,
            properties: {
              query: { type: Type.STRING, description: "The query search string" }
            },
            required: ["query"]
          }
        },
        {
          name: "openYouTube",
          description: "Launches YouTube and searches for a video or music query",
          parameters: {
            type: Type.OBJECT,
            properties: {
              query: { type: Type.STRING, description: "The video or song search term" }
            },
            required: ["query"]
          }
        },
        {
          name: "openMaps",
          description: "Opens Google Maps navigation for a specific address or location",
          parameters: {
            type: Type.OBJECT,
            properties: {
              location: { type: Type.STRING, description: "The city, landmark, or address to Navigate" }
            },
            required: ["location"]
          }
        },
        {
          name: "makeCall",
          description: "Places a phone call to a given phone number or contact name",
          parameters: {
            type: Type.OBJECT,
            properties: {
              phoneNumber: { type: Type.STRING, description: "The phone number or caller name" }
            },
            required: ["phoneNumber"]
          }
        },
        {
          name: "sendSMS",
          description: "Sends an SMS message to a given number with body text",
          parameters: {
            type: Type.OBJECT,
            properties: {
              number: { type: Type.STRING, description: "Destination phone number or contact" },
              message: { type: Type.STRING, description: "The SMS body text content" }
            },
            required: ["number", "message"]
          }
        },
        {
          name: "setAlarm",
          description: "Sets an alarm for a specific time",
          parameters: {
            type: Type.OBJECT,
            properties: {
              time: { type: Type.STRING, description: "The hour/minutes representation, e.g. '07:30 AM' or '22:00'" }
            },
            required: ["time"]
          }
        },
        {
          name: "openSettings",
          description: "Launches the Android System Settings panel",
          parameters: {
            type: Type.OBJECT,
            properties: {}
          }
        },
        {
          name: "copyText",
          description: "Copies custom text content into the device clipboard",
          parameters: {
            type: Type.OBJECT,
            properties: {
              content: { type: Type.STRING, description: "The text content to copy" }
            },
            required: ["content"]
          }
        },
        {
          name: "shareContent",
          description: "Triggers an Android sharing sheet with custom content",
          parameters: {
            type: Type.OBJECT,
            properties: {
              content: { type: Type.STRING, description: "The description or link content to share" }
            },
            required: ["content"]
          }
        },
        {
          name: "readNotifications",
          description: "Reads active notifications on the Android status bar area",
          parameters: {
            type: Type.OBJECT,
            properties: {}
          }
        },
        {
          name: "getInstalledApps",
          description: "Lists all installed third-party and system packages/apps",
          parameters: {
            type: Type.OBJECT,
            properties: {}
          }
        },
        {
          name: "addReference",
          description: "Saves reference material, notes, or memories to Dipti's database so they can be retrieved later",
          parameters: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "Simple title for the note" },
              content: { type: Type.STRING, description: "Detailed text content to store" },
              category: { type: Type.STRING, enum: ["general", "note", "reminder", "link", "contact"], description: "The classification category" }
            },
            required: ["title", "content", "category"]
          }
        },
        {
          name: "sendWhatsAppMessage",
          description: "Sends a secure text message to a specific contact on WhatsApp. Supported recipients: Preeti, Rahul, Amit.",
          parameters: {
            type: Type.OBJECT,
            properties: {
              recipient: { type: Type.STRING, description: "Recipient contact name, e.g. 'Preeti' or 'Rahul'" },
              message: { type: Type.STRING, description: "The message body text content" }
            },
            required: ["recipient", "message"]
          }
        },
        {
          name: "playMusic",
          description: "Plays simulated musical tracks on the device through the web player. You can play a specific genre/melody: 'bihu' (Assamese Folk), 'lofi' (Bollywood Raga), or 'dipti' (Acoustic Bells/OS theme).",
          parameters: {
            type: Type.OBJECT,
            properties: {
              trackName: { type: Type.STRING, description: "Optional track trackId or keyword filter: 'bihu', 'lofi', or 'dipti'" }
            }
          }
        },
        {
          name: "pauseMusic",
          description: "Pauses any active music playing on the device player",
          parameters: {
            type: Type.OBJECT,
            properties: {}
          }
        }
      ]
    }
  ];

  // Set up WebSocket Server Connection Broker with Gemini Live API
  wss.on("connection", async (clientWs: WebSocket) => {
    console.log("Client connected via WebSocket. Connecting to Gemini Live API...");
    let liveSession: any = null;
    let accumulatedModelText = "";

    try {
      const ai = getGeminiClient();

      // Fetch dynamic database references & conversations to establish permanent memory state
      const savedReferences = ServerDb.getReferences();
      const recentTurns = ServerDb.getConversations().slice(-15);

      // Inspect references to parse user's name
      let userName = "";
      for (const ref of savedReferences) {
        const normTitle = ref.title.toLowerCase();
        if (normTitle.includes("user name") || normTitle.includes("mera naam") || normTitle.includes("my name")) {
          userName = ref.content.trim();
          break;
        }
      }

      // Stringify references and conversational steps
      const formattedReferences = savedReferences.map(ref => `- [${ref.category}] ${ref.title}: ${ref.content}`).join("\n");
      const formattedConversations = recentTurns.map(t => `[${t.role === 'user' ? 'User' : 'Dipti'}]: ${t.text}`).join("\n");

      // Build personalized conversational system context
      const activeSystemInstruction = `${SYSTEM_INSTRUCTION}

Memory & Context State:
- Address the user as their memorized name if it's saved below. 
${userName ? `- The user name is saved as "${userName}". Address the user as "${userName}" and remember it permanently across current and future conversations. For example, say things like "Aapka naam ${userName} hai" or "Sure ${userName}!" or "Ki khobor ${userName}!".` : `- The user name is NOT in memory yet. If the user introduces themselves (e.g., 'Mera naam Deep hai', 'Moi Deep', or 'My name is Deep'), immediately run 'addReference' tool with EXACT title 'User Name', content: '[Name]' (e.g. 'Deep'), category 'general' so it is saved permanently. Address them with it thereafter. If they ask 'Mera naam kya hai?' and no user name is saved yet, inform them politely you don't know and ask for their name so you can note it down.`}

Currently Memorized Reference Database:
${formattedReferences || "(No reference entries written yet)"}

Recent Conversation History:
${formattedConversations || "(No past dialogues in database)"}
`;

      // Establish real-time bidirectional stream with gemini-3.1-flash-live-preview
      liveSession = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              // Kore represents Dipti's warm, playful female character model
              prebuiltVoiceConfig: { voiceName: "Kore" }, 
            },
          },
          systemInstruction: activeSystemInstruction,
          tools: toolsList,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            // Forward audio output to browser (PCM format, model replies at 24kHz)
            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio) {
              clientWs.send(JSON.stringify({ type: "audio", audio }));
            }

            // Capture and forward Gemini Live's real-time translations/input transcriptions
            const userText = message.serverContent?.inputTranscription?.text;
            if (userText) {
              console.log("User transcript:", userText);
              // Store in ServerDb
              const savedUr = ServerDb.addConversation({ role: 'user', text: userText, mediaType: 'voice' });
              clientWs.send(JSON.stringify({ type: "userTranscript", text: userText, turn: savedUr }));
            }

            const modelText = message.serverContent?.modelTurn?.parts?.map(p => p.text).filter(Boolean).join(" ");
            if (modelText) {
              console.log("Model transcript chunk:", modelText);
              accumulatedModelText += modelText + " ";
              // We'll accumulate these chunks on the client. But whenever there is text, send it
              clientWs.send(JSON.stringify({ type: "modelTranscript", text: modelText }));
            }

            // Check if model turn is complete to persist the accumulated transcript
            if ((message as any).serverContent?.modelTurn?.turnComplete && accumulatedModelText.trim()) {
              const fullText = accumulatedModelText.trim();
              console.log("Model turn completed. Saving response to ServerDb:", fullText);
              const savedModelTurn = ServerDb.addConversation({ role: 'model', text: fullText, mediaType: 'voice' });
              clientWs.send(JSON.stringify({ type: "modelTurnSaved", turn: savedModelTurn }));
              accumulatedModelText = "";
            }

            // Handle session interruption (e.g. user barging in while Dipti is talking)
            if (message.serverContent?.interrupted) {
              console.log("Dipti session interrupted by user speech.");
              accumulatedModelText = "";
              clientWs.send(JSON.stringify({ type: "interrupted" }));
            }

            // Handle Tool/Function calls triggered by Gemini
            if (message.toolCall) {
              console.log("Gemini triggered toolCall:", JSON.stringify(message.toolCall));
              // Forward tool call request to the client side where Android Bridge simulation executes it
              clientWs.send(JSON.stringify({
                type: "toolCall",
                functionCalls: message.toolCall.functionCalls
              }));
            }
          },
        },
      });

      console.log("Successfully connected system websocket with Gemini Live Session!");
      clientWs.send(JSON.stringify({ type: "status", status: "ready" }));

    } catch (err: any) {
      console.error("Failed to boot Gemini Live WebSocket Connection:", err);
      clientWs.send(JSON.stringify({ type: "error", error: err.message || String(err) }));
      clientWs.close();
      return;
    }

    // Handle incoming client audio inputs and tool responses
    clientWs.on("message", async (raw: Buffer) => {
      try {
        const msg = JSON.parse(raw.toString());

        // Stream input audio from micro (encoded PCM16 16kHz on client side)
        if (msg.audio && liveSession) {
          liveSession.sendRealtimeInput({
            audio: {
              data: msg.audio,
              mimeType: "audio/pcm;rate=16000",
            },
          });
        }

        // Return tool feedback result back to Gemini Session
        if (msg.type === "toolResponse" && liveSession) {
          console.log("Forwarding client toolResponse to Gemini session:", JSON.stringify(msg.functionResponses));
          
          // If the tool is 'addReference', let's also write it to the DB on the server right away!
          const refCall = msg.toolDetails;
          if (refCall && refCall.name === "addReference") {
            try {
              const savedRef = ServerDb.addReference({
                title: refCall.args.title,
                content: refCall.args.content,
                category: refCall.args.category || 'general'
              });
              // Send reference updated alert to GUI client
              clientWs.send(JSON.stringify({ type: "referenceAdded", data: savedRef }));
            } catch (refErr) {
              console.error("Local database reference logging failed:", refErr);
            }
          }

          liveSession.sendToolResponse({
            functionResponses: msg.functionResponses,
          });
        }

        // Keep-alive or other states
        if (msg.type === "ping") {
          clientWs.send(JSON.stringify({ type: "pong" }));
        }

      } catch (e) {
        console.error("Error processing browser socket frame:", e);
      }
    });

    clientWs.on("close", () => {
      console.log("Browser WebSocket closed. Disposing Gemini Live Session...");
      if (liveSession) {
        try {
          liveSession.close();
        } catch (e) {
          console.error("Error disposing LiveSession:", e);
        }
      }
    });
  });

  // Attach WebSocket upgraded broker path to standard server
  server.on("upgrade", (request, socket, head) => {
    const pathname = new URL(request.url || "", `http://${request.headers.host}`).pathname;
    if (pathname === "/live") {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit("connection", ws, request);
      });
    } else {
      socket.destroy();
    }
  });

  // Serve static UI assets and wire dev server vs prod dist paths
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Dipti AI Backend fully up and running on port ${PORT}`);
  });
}

startServer();
